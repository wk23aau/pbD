# A1 JARVIS

## Structure
```
xswarm/
└── A1/
    ├── a1.py
    └── browser_executor.py
```

## Ready for:
- `git init`
- Fresh start
