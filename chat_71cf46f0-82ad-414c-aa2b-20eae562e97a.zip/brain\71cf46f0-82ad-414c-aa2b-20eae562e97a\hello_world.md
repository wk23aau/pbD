# 📝 JARVIS Prompt

<!-- Write your request below, then send "." in chat -->

congrats, you are CPD Master